package com.example.aikeyboard

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

class LocalPredictionEngine(context: Context) {
    private val model: JSONObject = runCatching {
        context.assets.open("dictionaries/phrases.json").bufferedReader(Charsets.UTF_8).use {
            JSONObject(it.readText())
        }
    }.getOrElse { JSONObject() }

    fun predict(contextText: String, language: String, limit: Int = 3): List<String> {
        if (limit <= 0 || contextText.isBlank()) return emptyList()

        val words = tokenize(contextText)
        if (words.isEmpty()) return emptyList()

        val last = normalize(words.last())
        val previous = words.dropLast(1).lastOrNull()?.let(::normalize)

        val trigram = previous?.let {
            model.optJSONObject(it)?.optJSONArray(last).toList()
        }.orEmpty()

        val unigram = model.optJSONObject(last)?.optJSONArray("_next").toList()
        val candidates = (trigram + unigram)
            .filter { isLanguageCandidate(it, language) }
            .distinct()

        return candidates.take(limit)
    }

    private fun isLanguageCandidate(value: String, language: String): Boolean {
        if (language == "en") return value.any { it in 'A'..'Z' || it in 'a'..'z' }
        if (language == "ar") return value.any { it in '\u0600'..'\u06FF' }
        return true
    }

    private fun tokenize(text: String): List<String> = text
        .trim()
        .split(Regex("\\s+"))
        .map { it.trim() }
        .filter { it.isNotEmpty() }

    fun normalize(value: String): String = value
        .trim()
        .trimEnd('.', ',', '!', '?', '؟', '،', ':', ';', '؛')
        .lowercase(Locale.ROOT)
        .replace("أ", "ا")
        .replace("إ", "ا")
        .replace("آ", "ا")

    private fun JSONArray?.toList(): List<String> {
        if (this == null) return emptyList()
        return (0 until length()).mapNotNull { index ->
            optString(index).trim().takeIf { it.isNotEmpty() }
        }
    }
}

package com.example.aikeyboard

import android.content.Context
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

object AiClient {
    private const val CONNECT_TIMEOUT_MS = 10_000
    private const val READ_TIMEOUT_MS = 30_000

    fun run(context: Context, mode: String, text: String, callback: (Result<String>) -> Unit) {
        Thread {
            val result = runCatching {
                require(mode in setOf("spell", "formal", "friendly", "translate", "reply")) {
                    "وضع المعالجة غير معروف"
                }
                require(text.isNotBlank()) { "النص فارغ" }

                val prefs = context.getSharedPreferences("cfg", Context.MODE_PRIVATE)
                val base = prefs.getString("server", "").orEmpty().trim().trimEnd('/')
                require(base.startsWith("https://") || base.startsWith("http://")) {
                    "أدخل عنوان خادم صحيحاً يبدأ بـ http:// أو https://"
                }

                val connection = (URL("$base/ai").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = CONNECT_TIMEOUT_MS
                    readTimeout = READ_TIMEOUT_MS
                    doOutput = true
                    setRequestProperty("Accept", "application/json")
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    prefs.getString("token", "")?.trim()?.takeIf { it.isNotEmpty() }?.let {
                        setRequestProperty("x-app-token", it)
                    }
                }

                try {
                    val payload = JSONObject().put("mode", mode).put("text", text).toString()
                    connection.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
                    val body = (if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream)
                        ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                    if (connection.responseCode !in 200..299) {
                        val message = runCatching { JSONObject(body).optString("error") }.getOrNull()
                        error(message?.takeIf { it.isNotBlank() } ?: "فشل الخادم (${connection.responseCode})")
                    }
                    JSONObject(body).optString("result").takeIf { it.isNotBlank() }
                        ?: error("استجابة الخادم لا تحتوي على نتيجة")
                } finally {
                    connection.disconnect()
                }
            }
            callback(result)
        }.apply {
            isDaemon = true
            start()
        }
    }
}

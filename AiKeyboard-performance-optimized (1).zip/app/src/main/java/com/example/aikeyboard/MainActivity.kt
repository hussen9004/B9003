package com.example.aikeyboard

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.inputmethod.InputMethodManager
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("cfg", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 60, 40, 40)
        }
        fun label(text: String) = TextView(this).apply {
            this.text = text
            textSize = 16f
            setPadding(0, 16, 0, 8)
        }
        fun button(text: String, action: () -> Unit) = Button(this).apply {
            this.text = text
            setOnClickListener { action() }
        }

        val server = EditText(this).apply {
            hint = "https://your-server.example.com"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine(true)
            setText(prefs.getString("server", ""))
        }
        val token = EditText(this).apply {
            hint = "APP_TOKEN (اختياري إذا لم يضبطه الخادم)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine(true)
            setText(prefs.getString("token", ""))
        }

        box.addView(label("كيبود ذكي بالذكاء الاصطناعي"))
        box.addView(label("فعّل لوحة المفاتيح من إعدادات النظام، اخترها، ثم احفظ عنوان خادم الـ API."))
        box.addView(button("فتح إعدادات لوحات المفاتيح") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })
        box.addView(button("اختيار الكيبورد الآن") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })
        box.addView(label("عنوان الخادم")); box.addView(server)
        box.addView(label("رمز التطبيق")); box.addView(token)
        box.addView(button("حفظ الإعدادات") {
            val base = server.text.toString().trim().trimEnd('/')
            if (!base.startsWith("https://") && !base.startsWith("http://")) {
                server.error = "يجب أن يبدأ العنوان بـ http:// أو https://"
                return@button
            }
            prefs.edit().putString("server", base).putString("token", token.text.toString().trim()).apply()
            Toast.makeText(this, "تم حفظ الإعدادات", Toast.LENGTH_SHORT).show()
        })
        box.addView(button("صانع الملصقات من الاستديو") {
            startActivity(Intent(this, StickerActivity::class.java))
        })
        box.addView(label("يمكنك تجربة الكتابة بعد اختيار لوحة المفاتيح من النظام."))
        box.addView(EditText(this).apply { minLines = 3; gravity = android.view.Gravity.TOP })

        setContentView(ScrollView(this).apply { addView(box) })
    }
}

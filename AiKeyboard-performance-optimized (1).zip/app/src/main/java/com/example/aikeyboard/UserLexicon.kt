package com.example.aikeyboard

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.util.Locale

class UserLexicon(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences("user_lexicon", Context.MODE_PRIVATE)
    private val saveHandler = Handler(Looper.getMainLooper())
    private val saveRunnable = Runnable { flush() }
    private val lock = Any()

    private val words = mutableMapOf<String, Int>()
    private val nextWords = mutableMapOf<String, MutableMap<String, Int>>()
    private var loaded = false
    private var dirty = false

    fun recordText(text: String) {
        val tokens = tokenize(text)
        if (tokens.isEmpty()) return
        synchronized(lock) {
            ensureLoadedLocked()
            tokens.forEach { token -> words[token] = (words[token] ?: 0) + 1 }
            tokens.zipWithNext().forEach { (current, next) ->
                val candidates = nextWords.getOrPut(current) { mutableMapOf() }
                candidates[next] = (candidates[next] ?: 0) + 1
            }
            trimLocked()
            dirty = true
            scheduleFlush()
        }
    }

    fun recordSuggestion(value: String) = recordText(value)

    fun suggestWords(prefix: String, limit: Int = 3): List<String> {
        val normalized = normalize(prefix)
        if (normalized.isBlank()) return emptyList()
        synchronized(lock) {
            ensureLoadedLocked()
            return words.asSequence()
                .filter { (word, _) -> word.startsWith(normalized) && word != normalized }
                .sortedWith(compareByDescending<Pair<String, Int>> { it.second }.thenBy { it.first.length })
                .take(limit)
                .map { it.first }
                .toList()
        }
    }

    fun suggestNextWords(contextText: String, limit: Int = 3): List<String> {
        val last = tokenize(contextText).lastOrNull() ?: return emptyList()
        synchronized(lock) {
            ensureLoadedLocked()
            return nextWords[last].orEmpty().asSequence()
                .sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key.length })
                .take(limit)
                .map { it.key }
                .toList()
        }
    }

    fun clear() {
        synchronized(lock) {
            words.clear()
            nextWords.clear()
            loaded = true
            dirty = false
            saveHandler.removeCallbacks(saveRunnable)
            prefs.edit().remove("words").remove("next_words").apply()
        }
    }

    /** Writes the in-memory counters once instead of writing on every key press. */
    fun flush() {
        val wordsSnapshot: Map<String, Int>
        val nextSnapshot: Map<String, Map<String, Int>>
        synchronized(lock) {
            if (!dirty) return
            wordsSnapshot = words.toMap()
            nextSnapshot = nextWords.mapValues { it.value.toMap() }
            dirty = false
        }

        val wordsJson = JSONObject().apply { wordsSnapshot.forEach { (key, value) -> put(key, value) } }
        val nextJson = JSONObject().apply {
            nextSnapshot.forEach { (source, candidates) ->
                put(source, JSONObject().apply { candidates.forEach { (key, value) -> put(key, value) } })
            }
        }
        prefs.edit().putString("words", wordsJson.toString()).putString("next_words", nextJson.toString()).apply()
    }

    fun shutdown() {
        saveHandler.removeCallbacks(saveRunnable)
        flush()
    }

    private fun scheduleFlush() {
        saveHandler.removeCallbacks(saveRunnable)
        saveHandler.postDelayed(saveRunnable, 1_500L)
    }

    private fun ensureLoadedLocked() {
        if (loaded) return
        words.putAll(loadCounts(prefs.getString("words", null)))
        loadNestedCounts(prefs.getString("next_words", null)).forEach { (source, candidates) ->
            nextWords[source] = candidates.toMutableMap()
        }
        loaded = true
    }

    private fun trimLocked(maxWords: Int = 3000, maxSources: Int = 3000, maxCandidates: Int = 20) {
        if (words.size > maxWords) {
            val kept = words.entries.sortedByDescending { it.value }.take(maxWords)
            words.clear(); words.putAll(kept.associate { it.key to it.value })
        }
        if (nextWords.size > maxSources) {
            val kept = nextWords.entries.sortedByDescending { it.value.values.sum() }.take(maxSources)
            nextWords.clear(); nextWords.putAll(kept.associate { it.key to it.value })
        }
        nextWords.entries.forEach { entry ->
            if (entry.value.size > maxCandidates) {
                val kept = entry.value.entries.sortedByDescending { it.value }.take(maxCandidates)
                entry.value.clear(); entry.value.putAll(kept.associate { it.key to it.value })
            }
        }
    }

    private fun tokenize(text: String): List<String> = text.trim().split(Regex("\\s+"))
        .map(::normalize).filter { it.length >= 2 }

    private fun normalize(value: String): String = value.trim()
        .trim('.', ',', '!', '?', '؟', '،', ':', ';', '؛', '(', ')', '[', ']', '"', '\'')
        .lowercase(Locale.ROOT)
        .replace("أ", "ا").replace("إ", "ا").replace("آ", "ا")

    private fun loadCounts(raw: String?): Map<String, Int> {
        if (raw.isNullOrBlank()) return emptyMap()
        return runCatching {
            val json = JSONObject(raw)
            buildMap { json.keys().forEach { key -> put(key, json.optInt(key, 0)) } }
        }.getOrDefault(emptyMap())
    }

    private fun loadNestedCounts(raw: String?): Map<String, Map<String, Int>> {
        if (raw.isNullOrBlank()) return emptyMap()
        return runCatching {
            val json = JSONObject(raw)
            buildMap {
                json.keys().forEach { source ->
                    val nested = json.optJSONObject(source) ?: return@forEach
                    put(source, buildMap { nested.keys().forEach { key -> put(key, nested.optInt(key, 0)) } })
                }
            }
        }.getOrDefault(emptyMap())
    }
}

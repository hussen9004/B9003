import http from 'node:http';

const PORT = Number.parseInt(process.env.PORT || '8787', 10);
const KEY = process.env.ANTHROPIC_API_KEY?.trim();
const TOKEN = process.env.APP_TOKEN?.trim() || '';
const MODEL = process.env.MODEL?.trim() || 'claude-3-5-haiku-20241022';
const MAX_BODY_BYTES = 20_000;
const MAX_TEXT_LENGTH = 12_000;
const OUT = ' أعد النص الناتج فقط دون شرح أو علامات اقتباس.';

const PROMPTS = {
  spell: 'صحّح الإملاء والنحو في النص مع إضافة التشكيل الكامل، وحافظ على المعنى واللهجة.' + OUT,
  formal: 'أعد صياغة النص بأسلوب رسمي مهذب وبنفس اللغة.' + OUT,
  friendly: 'أعد صياغة النص بأسلوب ودي ودافئ وبنفس اللغة، ويمكنك إضافة إيموجي مناسب.' + OUT,
  translate: 'إن كان النص عربياً فترجمه إلى الإنجليزية، وإن كان بغيره فترجمه إلى العربية.' + OUT,
  reply: 'هذه رسالة وصلتني. اكتب رداً قصيراً ومناسباً بنفس لغة ولهجة المرسل.' + OUT,
};

function json(res, status, body) {
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    'x-content-type-options': 'nosniff',
  });
  res.end(JSON.stringify(body));
}

async function readBody(req) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > MAX_BODY_BYTES) throw Object.assign(new Error('الطلب كبير جداً'), { status: 413 });
    chunks.push(chunk);
  }
  return Buffer.concat(chunks).toString('utf8');
}

async function handleAi(req, res) {
  if (TOKEN && req.headers['x-app-token'] !== TOKEN) return json(res, 401, { error: 'رمز التطبيق غير صحيح' });

  let input;
  try {
    input = JSON.parse(await readBody(req));
  } catch (error) {
    return json(res, error.status || 400, { error: error.status ? error.message : 'JSON غير صالح' });
  }

  const mode = typeof input?.mode === 'string' ? input.mode : '';
  const text = typeof input?.text === 'string' ? input.text.trim() : '';
  if (!PROMPTS[mode] || !text) return json(res, 400, { error: 'الوضع أو النص غير صالح' });
  if (text.length > MAX_TEXT_LENGTH) return json(res, 413, { error: 'النص طويل جداً' });
  if (!KEY) return json(res, 503, { error: 'لم يتم ضبط ANTHROPIC_API_KEY على الخادم' });

  try {
    const upstream = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        accept: 'application/json',
        'content-type': 'application/json',
        'x-api-key': KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 600,
        system: PROMPTS[mode],
        messages: [{ role: 'user', content: text }],
      }),
    });
    const payload = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      console.error('Anthropic error:', upstream.status, payload);
      return json(res, 502, { error: 'تعذر تنفيذ الطلب لدى مزود الذكاء الاصطناعي' });
    }
    const result = Array.isArray(payload.content)
      ? payload.content.filter((part) => part?.type === 'text').map((part) => part.text).join('').trim()
      : '';
    if (!result) return json(res, 502, { error: 'لم يرجع مزود الذكاء الاصطناعي نصاً' });
    return json(res, 200, { result });
  } catch (error) {
    console.error('Request failed:', error);
    return json(res, 502, { error: 'تعذر الاتصال بمزود الذكاء الاصطناعي' });
  }
}

const server = http.createServer(async (req, res) => {
  if (req.method !== 'POST' || req.url !== '/ai') return json(res, 404, { error: 'المسار غير موجود' });
  await handleAi(req, res);
});

server.listen(PORT, () => console.log(`AI proxy listening on port ${PORT}`));
